<?php

namespace tests\Models;

use AbuseIO\Models\Incident;
use tests\TestCase;

class IncidentTest extends TestCase
{
    public function testModelFactory()
    {
        //        $incident = factory(Incident::class)->make();
        //        $this->assertInstanceOf(Incident::class, $incident);
        // TODO : code is here because can't figure out how to return a data object from model factory.
        $this->assertTrue(true);
    }
}
