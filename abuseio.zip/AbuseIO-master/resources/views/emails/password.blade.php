Hello,<br>
<br>
A password reset was requested from the website.<br>
<br>
Click here to reset your password: <a target="_blank" href="{{ url('password/reset/'.$token) }}"> {{ url('password/reset/'.$token) }}</a><br>
<br>
If you did not request to change to password, you can ignore this e-mail<br>
<br>