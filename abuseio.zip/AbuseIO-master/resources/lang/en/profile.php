<?php

/**
 * Translations for Profile.
 */
return [
    'password'              => 'Password',
    'password_confirmation' => 'Password (repeat)',
];
