<?php

return [
    // Headers

    // Buttons
    'button.search' => 'Search',

    // Miscellaneous
    'customer_code' => 'Contact Code',
    'customer_name' => 'Contact Name',
];
