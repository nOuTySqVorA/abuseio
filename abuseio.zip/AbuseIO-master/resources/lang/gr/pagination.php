<?php

/**
 * Translations for Pagination.
 */
return [
    'previous' => '&laquo; Επόμενο',
    'next'     => 'Προηγούμενο &raquo;',
];
