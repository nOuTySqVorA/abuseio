<?php

/**
 * Translations for Profile.
 */
return [
    'password'              => 'Κωδικός',
    'password_confirmation' => 'Κωδικός(επιβεβαίωση)',
];
