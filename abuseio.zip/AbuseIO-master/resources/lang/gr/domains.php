<?php

/**
 * Translations for Domains.
 */
return [
    // Headers
    'header.new'    => 'Νέο Domain',
    'header.edit'   => 'Επεξεργασία Domain',
    'header.detail' => 'Λεπτομέρεις Domain για',

    // Buttons
    'button.new_domain' => 'Νέο Domain',

    // Miscellaneous
    'no_domains' => 'Δεν υπάρχει ακόμα κανένα domain',
    'domainname' => 'Domain name',
];
