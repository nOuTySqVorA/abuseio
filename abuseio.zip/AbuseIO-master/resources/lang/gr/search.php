<?php

return [
    // Headers

    // Buttons
    'button.search' => 'Αναζήτηση',

    // Miscellaneous
    'customer_code' => 'Κωδικός Επαφής',
    'customer_name' => 'Όνομα Επαφής',
];
